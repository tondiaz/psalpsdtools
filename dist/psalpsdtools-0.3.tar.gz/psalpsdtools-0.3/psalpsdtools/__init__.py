from .Gaussiandistribution import Gaussian
from .Binomialdistribution import Binomial
from .ProvincesOfRegions import getPrvs
from .PhilippinesRegions import PhilippinesRegions