from setuptools import setup

setup(name='psalpsdtools',
      version='0.3',
      description='PSA-LPSD tools for processing',
      packages=['psalpsdtools'],
      author_email='a.diaziii@psa.gov.ph',
      zip_safe=False)
