from setuptools import setup

setup(name='psalpsdtools',
      version='0.5',
      description='PSA-LPSD Tools',
      packages=['psalpsdtools'],
      author_email='a.diaziii@psa.gov.ph',
      zip_safe=False)
